﻿using Stackoverflow.Classes;
using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class GetQuestions_BL
    {
        public List<Question> GetAllQuestions() 
        {
            List<Question> questions = new List<Question>(); 
            User_DAL database = new User_DAL();
            questions=database.GetAllQuestions();
            return questions;
        }
        public List<Question> GetSearchQuestions(string searchItem)
        {
            List<Question> questions = new List<Question>();
            User_DAL database = new User_DAL();
            questions = database.GetSearchQuestions(searchItem);
            return questions;
        }
    }
}