﻿using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class PostAnswer_BL
    {
        public string PostAnswer(int questionId,int userId, string description)
        {
            Answer answer = new Answer();
            string message = answer.Post(questionId,userId, description);
            return message;
        }
    }
}