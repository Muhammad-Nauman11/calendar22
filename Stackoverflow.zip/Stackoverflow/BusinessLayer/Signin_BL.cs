﻿using Stackoverflow.Classes;
using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class Signin_BL
    {
         public int signedUserId;
        public string UserSignin(string userdetail, string password) 
        {
            User user = new User();
            string regMsg = user.Signin(userdetail, password);
            if (regMsg.Contains("success"))
            {
                signedUserId = user.UserId;
            }
            return regMsg;
        }
        public User getSignedUser()
        {
            User_DAL database = new User_DAL();
            List<string> userDetails = database.UserDetails(signedUserId);
            User user = new User();
            if (userDetails.Count > 0) 
            {
                user.UserId = signedUserId;
                user.UserName = userDetails[0];
                user.UserEmail = userDetails[1];
                user.UserCountry = userDetails[2];
            }

            return user;
        }
    }
}