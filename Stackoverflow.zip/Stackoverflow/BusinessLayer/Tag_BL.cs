﻿using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using Stackoverflow.DataAccessLayer;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class Tag_BL
    {
        public List<Tag> GetTags() 
        {
            List<Tag> tagData = new List<Tag>();
            User_DAL database = new User_DAL();
            tagData = database.GetAllTags();
            return tagData;
        }
        public List<Tag> GetSearchedTags(string searchText)
        {
            List<Tag> tagData = new List<Tag>();
            User_DAL database = new User_DAL();
            tagData = database.GetSearchedTags(searchText);
            return tagData;
        }
    }
}