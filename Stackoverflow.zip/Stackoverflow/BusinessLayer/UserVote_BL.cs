﻿using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class UserVote_BL
    {
        public int CheckUserVote(string elementType, int questionId, int answerId, int userId) 
        {
            if (elementType == "question")
            {
                Vote_DAL userVoteDL = new Vote_DAL();
                return userVoteDL.CheckUserVotedQuestion(questionId, userId);
            }
            else 
            {
                Vote_DAL userVoteDL = new Vote_DAL();
                return userVoteDL.CheckUserVotedAnswer(questionId, answerId, userId);
            }
        }
        public int UpdateUserVote(int answerId, int userId, int action) 
        {
            Vote_DAL userVoteDL = new Vote_DAL();
            return userVoteDL.UpdateUserVote(answerId, userId, action);
        }
    }
}