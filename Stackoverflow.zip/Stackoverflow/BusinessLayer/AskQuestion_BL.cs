﻿using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class AskQuestion_BL
    {
        public string AskQuestion(int userId, string title, string description, int[] tagsId)
        {
            Question question = new Question();
            string message = question.AskQuestion(userId, title, description);
            for (int i = 0; i < tagsId.Length; i++) 
            {
                Tag tag = new Tag();
                tag.id = (int)tagsId[i];
                string tagAddingMessage=question.AddTag(tag);
                if (tagAddingMessage == "failure") 
                {
                    message = "Failed to add tags";
                }
            }
            return message;
        }

    }
}