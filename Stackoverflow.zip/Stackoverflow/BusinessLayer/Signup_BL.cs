﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Stackoverflow.Classes;
namespace Stackoverflow.BusinessLayer
{
    public class Signup_BL
    {
        string Name { get; set; }
        string Email { get; set; }
        string Password { get; set; }
        public User user { get; set; }
        public Signup_BL() 
        {
        
        }
        public Signup_BL(string name, string email, string password) 
        {
            Name = name;
            Email = email;
            Password = password;
        }
        public string Register(string name, string email, string password,string confirmPassword,string country) 
        {
            if (!ValidateName(name)) 
            {
                return "Name must be atleast 5 characters long and should not start with number.";
            }
            else if (confirmPassword != password)
            {
                return "Passowrds do not match";
            }
            else if(!ValidateEmail(email))
            {
                return "Email format is invalid. It should not start with number";
            }
            else if (!ValidatePassword(password))
            {
                return "Password must have an upper, a lower, a numeric, a special and 8 to 15 characters";
            }
            User testUser = new User();
            string message = testUser.Register(name, email, password,country);
            if (testUser.UserId > 0) 
            {
                user = testUser;
            }
            return message;


        }
        public bool ValidateName(string name)
        {
            if (name.Length < 5)
            {
                return false;
            }
            else if (Char.IsDigit(name[0])) 
            {
                return false;
            }
            return true;
        }
        public bool ValidateEmail(string email)
        {

            if (!email.EndsWith(".com") || !email.Contains("@") || Char.IsDigit(email[0]))
            {
                return false;
            }
            return true;
        }
        public bool ValidatePassword(string password)
        {
            bool isUpperCase = false;
            bool isLowerCase = false;
            bool isNumeric = false;
            if (password.Length < 8 || password.Length > 15)
            {
                return false;
            }
            for (int i = 0; i < password.Length; i++)
            {
                if (Char.IsDigit(password[i]))
                {
                    isLowerCase = true;
                }
                if (Char.IsLower(password[i]))
                {
                    isNumeric = true;
                }
                if (Char.IsUpper(password[i]))
                {
                    isUpperCase = true;
                }
            }
            return (isUpperCase && isLowerCase && isNumeric);
        }
    }
}