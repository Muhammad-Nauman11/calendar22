﻿using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.BusinessLayer
{
    public class AcceptAnswer_BL
    {
        public string AcceptAnswer(int answerId, int acceptance) 
        {
            Answer_DAL answerDAL = new Answer_DAL();
            int status=answerDAL.AcceptAnswer(answerId, acceptance);
            if (status < 1) 
            {
                return "Failed to accept";
            }
            return "Answer accepted successfully.";
        }
    }
}