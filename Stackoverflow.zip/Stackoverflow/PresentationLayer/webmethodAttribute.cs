﻿using System;

namespace Stackoverflow.PresentationLayer
{
    internal class webmethodAttribute : Attribute
    {
    }
}