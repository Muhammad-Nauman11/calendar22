﻿using Stackoverflow.BusinessLayer;
using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stackoverflow.PresentationLayer
{
    public partial class Signin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string userSignin(string email, string password)
        {

            Signin_BL signinBL = new Signin_BL();
            string regMsg = signinBL.UserSignin(email, password);
            if (regMsg.Contains("success"))
            {
                User user = signinBL.getSignedUser();
                HttpContext.Current.Session["User"] = user;
                return $"{regMsg},{user.UserId},{user.UserName},{user.UserEmail},{user.UserCountry}";
            }
            return regMsg;

        }
    }
}