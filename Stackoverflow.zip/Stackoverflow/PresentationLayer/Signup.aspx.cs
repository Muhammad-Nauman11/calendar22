﻿using Stackoverflow.BusinessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stackoverflow.PresentationLayer
{
    public partial class Signup : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        [WebMethod]
        public static string UserSignup(string name,string email, string password, string password2, string country) 
        {

            Signup_BL signupObj = new Signup_BL();
            string message= signupObj.Register(name, email, password,password2,country);
            HttpContext.Current.Session["User"] = signupObj.user;
            if (message.Contains("success")) 
            {
                return $"{message},{signupObj.user.UserId},{signupObj.user.UserName},{signupObj.user.UserEmail},{signupObj.user.UserCountry}";
            }
            return message;
        
        }
    }
}