﻿using Stackoverflow.BusinessLayer;
using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Script.Serialization;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stackoverflow.PresentationLayer
{
    public partial class PostQuestion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["User"]==null) 
            {
                Response.Redirect("Signin.aspx");
            }
        }
        [WebMethod]
        public static List<Tag> GetAllSearchedTags(string searchText)
        {
            Tag_BL tagBL = new Tag_BL();
            
            return tagBL.GetSearchedTags(searchText);
        }

        [WebMethod]
        public static string AskQuestion(string title, string description, string tagsId)
       {
            User user = (User)HttpContext.Current.Session["User"];

            AskQuestion_BL askQuestionBL = new AskQuestion_BL();
            int[] tagsIds = tagsId.Split(',').Select(Int32.Parse).ToArray();
            string msg=askQuestionBL.AskQuestion(user.UserId, title, description, tagsIds);
            return msg;
            

        }

    }
}