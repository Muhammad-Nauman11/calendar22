﻿using Stackoverflow.BusinessLayer;
using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Stackoverflow.PresentationLayer
{
    public partial class Answers : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (HttpContext.Current.Session["User"] == null)
            {
                answerText.ReadOnly = true;
            }
            else
            {
                answerText.ReadOnly = false;
            }

        }
        [WebMethod]
        public static string PostAnswer(string questionId, string description)
        {
            if (HttpContext.Current.Session["User"] == null)
            {
                return "You are not sign in. Please, sign in to give answer.";
            }
            else { 
                User user = (User)HttpContext.Current.Session["User"];

                PostAnswer_BL postAnswerBL = new PostAnswer_BL();
                string msg = postAnswerBL.PostAnswer(Convert.ToInt32(questionId), user.UserId, description);
                if (msg.Contains("success"))
                {
                    msg = "Answer posted successfully.";
                }
                return msg;
            }


        }
        [WebMethod]
        public static string UserVote(string checkingType, string questionId,string answerId, string userId)
        {

            UserVote_BL userVoteBL = new UserVote_BL();
            string msg = userVoteBL.CheckUserVote(checkingType, Convert.ToInt32(questionId), Convert.ToInt32(answerId), Convert.ToInt32(userId)).ToString();
            return msg;



        }
        [WebMethod]
        public static string UpdateVote(string answerId, string userId, string action)
        {

            UserVote_BL userVoteBL = new UserVote_BL();
            string msg = userVoteBL.UpdateUserVote( Convert.ToInt32(answerId), Convert.ToInt32(userId), Convert.ToInt32(action)).ToString();
            return msg;



        }
        [WebMethod]
        public static string AcceptAnswer(string answerId,string acceptance)
        {

            AcceptAnswer_BL userVoteBL = new AcceptAnswer_BL();
            string msg = userVoteBL.AcceptAnswer(Convert.ToInt32(answerId), Convert.ToInt32(acceptance)).ToString();
            return msg;



        }
    }
}