﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Stackoverflow.DataAccessLayer
{
    public class Answer_DAL
    {

        protected SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =Stackoverflow;User ID=curemd; Password=abc");
        public int  AcceptAnswer(int answerId,int acceptance)
        {
            try
            {
                int voteChecking = 0;
                SqlCommand command = new SqlCommand("sp_acceptAnswer", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@AnswerId", answerId);
                command.Parameters.AddWithValue("@AcceptanceStatus", acceptance);
                connection.Open();
                var pReturnValue = command.Parameters.Add("@ReturnValue", SqlDbType.Int);
                pReturnValue.Direction = ParameterDirection.ReturnValue;
                command.ExecuteNonQuery();
                connection.Close();
                voteChecking = Convert.ToInt32(pReturnValue.Value);
                return voteChecking;
            }
            catch (Exception e)
            {
                Console.Write($"Error in Accepting answer: {e}");
                return 0;
            }
        }
    }
}