﻿using Stackoverflow.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Web;

namespace Stackoverflow.DataAccessLayer
{
    public class User_DAL
    {

        protected SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =Stackoverflow;User ID=curemd; Password=abc");
        public User_DAL()
        {

        }
        public int RegisterUser(string name, string email, string password, string country)
        {
            StringBuilder errorMessages = new StringBuilder();
            try
            {
                SqlCommand command = new SqlCommand("sp_Signup", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Username", name);
                command.Parameters.AddWithValue("@Email", email);
                command.Parameters.AddWithValue("@Password", password);
                command.Parameters.AddWithValue("@Country", country);
                connection.Open();


                SqlDataReader rdr = command.ExecuteReader();
                int userId = 0;
                while (rdr.Read())
                {
                    userId = Convert.ToInt32(rdr["UserId"]);

                }
                connection.Close();
                return userId;
            }
            catch (SqlException ex)
            {
                for (int i = 0; i < ex.Errors.Count; i++)
                {
                    errorMessages.Append("Index #" + i + "\n" +
                        "Message: " + ex.Errors[i].Message + "\n" +
                        "LineNumber: " + ex.Errors[i].LineNumber + "\n" +
                        "Source: " + ex.Errors[i].Source + "\n" +
                        "Procedure: " + ex.Errors[i].Procedure + "\n");
                }
                Console.WriteLine(errorMessages.ToString());
                return -1;
            }
        }
        public bool CheckNameExistance(string name)
        {
            SqlCommand command = new SqlCommand("sp_checkNameExistance", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Name", name);
            var pReturnValue = command.Parameters.Add("@ReturnValue", SqlDbType.Int);
            pReturnValue.Direction = ParameterDirection.ReturnValue;
            connection.Open();

            command.ExecuteNonQuery();
            connection.Close();
            if (Convert.ToInt32(pReturnValue.Value) > 0)
            {
                return true;
            }
            return false;
        }
        public bool CheckEmailExistance(string email)
        {

            SqlCommand command = new SqlCommand("sp_checkEmailExistance", connection);
            command.CommandType = CommandType.StoredProcedure;
            command.Parameters.AddWithValue("@Email", email);

            var pReturnValue = command.Parameters.Add("@ReturnValue", SqlDbType.Int);
            pReturnValue.Direction = ParameterDirection.ReturnValue;
            connection.Open();
            command.ExecuteNonQuery();
            connection.Close();
            if (Convert.ToInt32(pReturnValue.Value) > 0)
            {
                return true;
            }
            return false;

        }


        public string Login(string userdetail, string password)
        {

            bool isEmailValid = CheckEmailExistance(userdetail);

            if (isEmailValid)
            {
                SqlCommand command = new SqlCommand("sp_Signin", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Userdetail", userdetail);
                command.Parameters.AddWithValue("@Password", password);
               
                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();
                int userId = 0 ;
                while (rdr.Read()) 
                {
                    userId = (int)rdr["User_Id"];

                }
                connection.Close();
                if (userId > 0)
                {
                    return $"{userId}/success";
                }
                return "Incorrect";
            }
            else
            {

                return "not exist";

            }
        }
        public List<string> UserDetails(int userId)
        {
            List<string> userDetails= new List<string>();
            using (connection)
            {
                connection.Open();
                SqlCommand com = new SqlCommand("sp_getUserDetails", connection);
                com.Parameters.AddWithValue("@UserId", userId);
                com.CommandType = CommandType.StoredProcedure;
                SqlDataReader rdr = com.ExecuteReader();
                while (rdr.Read())
                {
                    string userName = rdr["Username"].ToString();
                    string userEmail = rdr["Email"].ToString();
                    string userCountry = rdr["Country"].ToString();
                    userDetails.Add(userName);

                    userDetails.Add(userEmail); 
                    
                    userDetails.Add(userCountry);
                }
                connection.Close();
            }
            return userDetails;
        }
        public List<Tag> GetAllTags() 
        {
            List<Tag> tagList = new List<Tag>();

            connection.Open();
            SqlCommand command = new SqlCommand("sp_getAllTags", connection);

            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rdr = command.ExecuteReader();
            while (rdr.Read())
            {
                Tag tag = new Tag();
                tag.id = Convert.ToInt32(rdr["Tag_Id"]);
                tag.name = rdr["TagName"].ToString();
                tagList.Add(tag);
            }
            connection.Close();
            return tagList;
        }
        public List<Tag> GetSearchedTags(string searchItem)
        {
            List<Tag> tagList = new List<Tag>();

            connection.Open();
            SqlCommand command = new SqlCommand("sp_getSearchedTags", connection);
            command.Parameters.AddWithValue("@SearchTag", searchItem);
            command.CommandType = CommandType.StoredProcedure;
            SqlDataReader rdr = command.ExecuteReader();
            while (rdr.Read())
            {
                Tag tag = new Tag();
                tag.id = Convert.ToInt32(rdr["Tag_Id"]);
                tag.name = rdr["TagName"].ToString();
                tagList.Add(tag);
            }
            connection.Close();
            return tagList;
        }
        public int PostQuestion(int userId, string title, string description) 
        {
            try
            {
                SqlCommand command = new SqlCommand("sp_addQuestion", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserID", userId);
                command.Parameters.AddWithValue("@Title", title);
                command.Parameters.AddWithValue("@Description", description);

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();
                int questionId = 0;
                while (rdr.Read())
                {
                    questionId = Convert.ToInt32(rdr["Question_Id"]);
                }
                connection.Close();
                return questionId;
            }
            catch (Exception e)
            {
                Console.Write(e);
                return 0;
            }


        }
        public string AddQuestionTag(int questionId,int tagId)
        {

            try
            {
                SqlCommand command = new SqlCommand("sp_addQuestionTag", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@Tag_Id", tagId);
                command.Parameters.AddWithValue("@Question_Id", questionId);


                connection.Open();
                command.ExecuteNonQuery();


                connection.Close();
                return "success";
            }
            catch (Exception e)
            {
                Console.Write(e);
                return "failure";
            }


        }
        public List<Question> GetAllQuestions() 
        {
            List<Question> questions = new List<Question>();
            try
            {

                SqlCommand command = new SqlCommand("sp_getAllQuestions", connection);
                command.CommandType = CommandType.StoredProcedure;

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();

                while (rdr.Read())
                {
                    Question question = new Question();
                    question.id = Convert.ToInt32(rdr["Question_Id"]);
                    question.userId = Convert.ToInt32(rdr["User_Id"]);
                    question.title = Convert.ToString(rdr["Title"]);
                    question.description = Convert.ToString(rdr["Description"]);
                    question.uploadDatetime = Convert.ToString(rdr["UploadDatetime"]);
                    question.username = Convert.ToString(rdr["Username"]);
                    question.vote = (new Vote_DAL()).GetQuestionVote(question.id);
                    questions.Add(question);


                }
                connection.Close();
                for (int i = 0; i < questions.Count; i++) 
                {
                    questions[i].answers = GetAnswers(questions[i].id);
                    questions[i].tags = GetQuestionTags(questions[i].id);
                }
                return questions;

            }
            catch (Exception e)
            {
                Console.Write($"{e} in GetAllQuestions");
                return questions;
            }
        }
        public List<Question> GetSearchQuestions(string searchItem)
        {
            List<Question> questions = new List<Question>();
            try
            {

                SqlCommand command = new SqlCommand("sp_getSearchedQuestions", connection);
                command.Parameters.AddWithValue("@searchField", searchItem);
                command.CommandType = CommandType.StoredProcedure;

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();

                while (rdr.Read())
                {
                    Question question = new Question();
                    question.id = Convert.ToInt32(rdr["Question_Id"]);
                    question.userId = Convert.ToInt32(rdr["User_Id"]);
                    question.title = Convert.ToString(rdr["Title"]);
                    question.description = Convert.ToString(rdr["Description"]);
                    question.uploadDatetime = Convert.ToString(rdr["UploadDatetime"]);
                    question.username = Convert.ToString(rdr["Username"]);
                    question.vote = (new Vote_DAL()).GetQuestionVote(question.id);
                    questions.Add(question);


                }
                connection.Close();
                for (int i = 0; i < questions.Count; i++)
                {
                    questions[i].answers = GetAnswers(questions[i].id);
                    questions[i].tags = GetQuestionTags(questions[i].id);
                }
                return questions;

            }
            catch (Exception e)
            {
                Console.Write($"{e} in GetSearchQuestions");
                return questions;
            }
        }


        public List<Tag> GetQuestionTags(int questionId) 
        {
            List<Tag> tags = new List<Tag>();
            try
            {

                SqlCommand command = new SqlCommand("sp_getQuestionTags", connection);
                command.Parameters.AddWithValue("@QuestionId", questionId);
                command.CommandType = CommandType.StoredProcedure;

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();

                while (rdr.Read())
                {
                    Tag tag = new Tag();
                    tag.id = Convert.ToInt32(rdr["Tag_Id"]);
                    tag.name = Convert.ToString(rdr["TagName"]);
  
                    tags.Add(tag);


                }
                connection.Close();
                return tags;

            }
            catch (Exception e)
            {
                Console.Write($"{e} in GetQuestionTags");
                return tags;
            }
        }
        public List<Answer> GetAnswers(int questionId)
        {
            List<Answer> answers = new List<Answer>();
            try
            {

                SqlCommand command = new SqlCommand("sp_getQuestionAnswers", connection);
                command.Parameters.AddWithValue("@QuestionId", questionId);
                command.CommandType = CommandType.StoredProcedure;

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();

                while (rdr.Read())
                {
                    Answer answer = new Answer();
                    answer.questionId = questionId;
                    answer.id = Convert.ToInt32(rdr["Answer_Id"]);
                    answer.userId = Convert.ToInt32(rdr["User_Id"]);
                    answer.description = Convert.ToString(rdr["Description"]);
                    answer.username = Convert.ToString(rdr["Username"]);
                    answer.uploadDatetime = Convert.ToString(rdr["UploadDate"]);
                    answer.acceptance = Convert.ToInt32(rdr["AcceptanceStatus"]);
                    answer.vote = (new Vote_DAL()).GetAnswerVote(answer.id);
                    answers.Add(answer);


                }
                connection.Close();
                return answers;

            }
            catch (Exception e)
            {
                Console.Write($"{e} in GetAnswers");
                return answers;
            }
        }
        public int PostAnswer(int questionId, int userId, string description) 
        {
            try
            {
                SqlCommand command = new SqlCommand("sp_addAnswer", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@UserID", userId);
                command.Parameters.AddWithValue("QuestionID", questionId);
                command.Parameters.AddWithValue("@Description", description);

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();
                int answerId = 0;
                while (rdr.Read())
                {
                    answerId = Convert.ToInt32(rdr["Answer_Id"]);
                }
                connection.Close();
                return answerId;
            }
            catch (Exception e)
            {
                Console.Write(e);
                return 0;
            }
        }
    }
}