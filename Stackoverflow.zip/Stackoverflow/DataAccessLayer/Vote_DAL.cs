﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Stackoverflow.DataAccessLayer
{
    public class Vote_DAL
    {

        protected SqlConnection connection = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;Initial Catalog =Stackoverflow;User ID=curemd; Password=abc");

        public int CheckUserVotedQuestion(int questionId, int userId)
        {
            try
            {
                int voteChecking = 0;
                SqlCommand command = new SqlCommand("sp_checkUserQuestionVote", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@QuestionId", questionId);
                command.Parameters.AddWithValue("@UserId", userId);

                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();
                while (rdr.Read())
                {
                    voteChecking = Convert.ToInt32(rdr["Action"]);
                }

                connection.Close();

                return voteChecking;
            }
            catch (Exception e) 
            {
                Console.Write($"Error in CheckUserVoteQuestion: {e}");
                return 0;
            }

        }

        public int CheckUserVotedAnswer(int questionId,int answerId, int userId)
        {
            try { 
                int voteChecking = 0;
                SqlCommand command = new SqlCommand("sp_checkUserAnswerVote", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@AnswerId", answerId);
                command.Parameters.AddWithValue("@UserId", userId);
                connection.Open();
                SqlDataReader rdr = command.ExecuteReader();
                while (rdr.Read())
                {
                    voteChecking = Convert.ToInt32(rdr["Action"]);
                }

                connection.Close();

                return voteChecking;
            }
            catch (Exception e)
            {
                Console.Write($"Error in CheckUserVoteQuestion: {e}");
                return 0;
            }

        }
        public int UpdateUserVote(int answerId, int userId, int action) 
        {
            try
            {
                int voteChecking = 0;
                SqlCommand command = new SqlCommand("sp_updateAnswerVote", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@AnswerId", answerId);
                command.Parameters.AddWithValue("@UserId", userId);
                command.Parameters.AddWithValue("@Action", action);
                connection.Open();
                var pReturnValue = command.Parameters.Add("@ReturnValue", SqlDbType.Int);
                pReturnValue.Direction = ParameterDirection.ReturnValue;
                command.ExecuteNonQuery();
                connection.Close();
                voteChecking = Convert.ToInt32(pReturnValue.Value);
                return voteChecking;
            }
            catch (Exception e)
            {
                Console.Write($"Error in CheckUserVoteQuestion: {e}");
                return 0;
            }
        }
        public int GetQuestionVote(int questionId) 
        {
            try
            {
                int vote = 0;
                SqlCommand command = new SqlCommand("sp_getQuestionVote", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@QuestionId", questionId);

                connection.Open();

                SqlDataReader rdr = command.ExecuteReader();
                while (rdr.Read())
                {
                    vote = Convert.ToInt32(rdr["votes"]);
                }
                connection.Close();
                return vote;
            }
            catch (Exception e)
            {
                Console.Write($"Error in CheckUserVoteQuestion: {e}");
                return 0;
            }

        }
        public int GetAnswerVote(int answerId)
        {
            try
            {
                int vote = 0;
                SqlCommand command = new SqlCommand("sp_getAnswerVote", connection);
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.AddWithValue("@AnswerId", answerId);

                connection.Open();

                SqlDataReader rdr = command.ExecuteReader();
                while (rdr.Read())
                {
                    vote = Convert.ToInt32(rdr["votes"]);
                }
                connection.Close();

                return vote;
            }
            catch (Exception e)
            {
                Console.Write($"Error in CheckUserVoteQuestion: {e}");
                return 0;
            }

        }
    }
}