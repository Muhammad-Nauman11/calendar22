﻿using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.Classes
{
    public class Answer
    {
        public int id { get; set; }
        public int questionId { get; set; }
        public int userId { get; set; }
        public string description { get; set; }
        public string uploadDatetime { get; set; }
        public string username { get; set; }
        public int vote { get; set; }
        public int acceptance { get; set; }

        public string Post(int questionid,int qUserId, string qDescription)
        {
            description = qDescription;
            userId = qUserId;
            questionId = questionid;
            User_DAL database = new User_DAL();
            id = database.PostAnswer(questionId,userId, description);
            string message = "success";
            if (id <= 0) 
            {
                message = "Failure in posting the answer";
            }
            return message;

        }
    }
}