﻿using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.Classes
{
    public class Question
    {
        public int id { get; set; }
        public int userId { get; set; }
        public string title { get; set; }
        public string description { get; set; }
        public int numberOfAnswers { get; set; }
        public string uploadDatetime { get; set; }
        public string username { get; set; }
        public List<Answer> answers { get; set; }
        public List<Tag> tags { get; set; }
        public int vote {get; set;}

        public string AskQuestion(int qUserId, string qTitle, string qDescription) 
        {
            title = qTitle;
            description = qDescription;
            userId = qUserId;
            User_DAL database = new User_DAL();
            id=database.PostQuestion(userId, title, description);
            return "success";

        }
        public string AddTag(Tag tag) 
        {
            User_DAL database = new User_DAL();
            return database.AddQuestionTag(id, tag.id);
        }
    }
}