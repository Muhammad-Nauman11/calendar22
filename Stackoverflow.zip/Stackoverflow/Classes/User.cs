﻿using Stackoverflow.DataAccessLayer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Stackoverflow.Classes
{
    public class User
    {
        public int UserId { get; set; }
        public string UserName { get; set; }
        public string UserEmail { get; set; }
        public string UserPassword { get; set; }
        public string UserCountry { get; set; }
        public User() 
        {
            
        }
        public User(string name, string email, string password) 
        {
            UserName = name;
            UserEmail = email;
            UserPassword = password;
        }

        public string Register(string name, string email, string password, string country)
        {
            User_DAL database = new User_DAL();
            if (database.CheckNameExistance(name))
            {
                return "Username already exists.";
            }
            else if (database.CheckEmailExistance(email)) 
            {
                return "Email already exists.";
            }
            UserId=database.RegisterUser(name,email, password, country);
            if (UserId>0) 
            {
                return $"User is registered successfully";
            }
            if (UserId < 0) 
            {
                return "Registered but failed to get User Id. Try to sign in";
            }
            return "Unable to register user.";
        }
        public string Signin(string userdetail, string password) 
        {
            User_DAL database = new User_DAL();
            string message= database.Login(userdetail, password);
            if (message.Contains("success"))  
            {
                UserId = Convert.ToInt32(message.Split('/')[0]);
                message = message.Split('/')[1];
            }
            return message;
        }

    }
}