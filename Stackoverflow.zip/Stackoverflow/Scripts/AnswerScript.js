﻿var question = JSON.parse(sessionStorage.getItem("Question"))
var voteState = 0
var user = "none"
if (sessionStorage.getItem("user") != null) {
    user = (sessionStorage.getItem("user")).split(',')
    console.log(user, 'inn')

}
var userVotes=[]
DisplayQuestion()
DisplayAnswers()
function DisplayQuestion()
{
    var container = document.getElementById("question")
    var questionBox = document.createElement("div")
    CheckUserVoted("question",0)
    var backgroundUp = 'transparent'
    var backgroundDown='transparent'

    questionBox.innerHTML =
        `
        <div class="text-primary h2">${question.title}</div>    <hr />
        <div class="d-flex flex-row">
            <div style="width:20%;">
                <button class="btn btn-secondary my-2 my-sm-0 d-flex align-self-center" id="${question.id}-q-up" onclick="UpdateVote(this,'${question.id}-q-down')" type="button" style="background-color:${backgroundUp}" data-toggle="tooltip" title="I like it">🔺</button>
                <span class="badge text-warning m-3 d-flex align-self-center" style="font-size:16px;" id="${question.id}-q">${question.vote}</span>            
                <button class="btn btn-secondary my-2 my-sm-0 d-flex align-self-center" id="${question.id}-q-down" onclick="UpdateVote(this,'${question.id}-q-up')" type="button" style="background-color:${backgroundDown}" data-toggle="tooltip" title="Not worthy">🔻</button>
            </div>
                <div style="width:80%;"><div>${question.description}<br/></div>
                <div class="text-right"><br/>
                    By <span class="text-primary">${question.username}</span> on ${question.uploadDatetime}
                </div>
            </div>
        </div>


        `
    container.appendChild(questionBox)
}
function DisplayAnswers()
{
    var allAnswers = document.getElementById('answers')
    var answerHead = document.createElement("div")
    answerHead.innerHTML =
        `
        <div class="text-secondary h3">${question.answers.length} Answers</div>    <hr />
        `
    allAnswers.appendChild(answerHead)
    for (var i = 0; i < question.answers.length; i++) { 
        var answerBox = document.createElement("div")
        var checkstatus = ``

        var tick = ``
        var acceptBtn =``
        
        console.log(parseInt(question.answers[i].acceptance))

        if (parseInt(question.answers[i].acceptance) == 1)
        {
            tick = `✔️`
        }
        checkstatus = `<span class="align-self-center" id="${question.answers[i].id}-check" style="color:red; font-size:35px;">${tick}</span>`
        if (user != "none") {
            if (parseInt(user[1]) == parseInt(question.userId)) {
                if (parseInt(question.answers[i].acceptance) == 1) {
                    acceptBtn = `<button type="button" id="${question.answers[i].id}-btn" class="btn btn-success" onclick="AcceptAnswer(this,${question.answers[i].id})">Reject</button>`
                }
                else
                {
                    acceptBtn = `<button type="button" id="${question.answers[i].id}-btn" class="btn btn-success" onclick="AcceptAnswer(this,${question.answers[i].id})">Accept</button>`
                }
            }
            
        }
        CheckUserVoted("answer", question.answers[i].id )
        answerBox.innerHTML =
           ` <div class="d-flex flex-row">
                <div style="width:15%;">

                    <button class="btn btn-secondary my-2 my-sm-0 d-flex align-self-center" id="${question.answers[i].id}-a-up" onclick="UpdateVote(this,'${question.answers[i].id}-a-down')" type="button" style="background-color:transparent" data-toggle="tooltip" title="I like it">🔺</button>
                    <span class="badge text-warning m-3 d-flex align-self-center" style="font-size:16px;" id="${question.answers[i].id}-a">${question.answers[i].vote}</span>            
                    <button class="btn btn-secondary my-2 my-sm-0 d-flex align-self-center" type="button" id="${question.answers[i].id}-a-down" onclick="UpdateVote(this,'${question.answers[i].id}-a-up')" style="background-color:transparent" data-toggle="tooltip" title="Not worthy">🔻</button>

                </div>
                <div style="width:70%;"><div>${question.answers[i].description}<br/></div>
                    <div class="text-right"><br/>
                        By <span class="text-primary">${question.answers[i].username}</span> on ${question.answers[i].uploadDatetime}
                    </div>
                    
                </div>
                <div style="width:15%;" class="text-center">${checkstatus}<br/>${acceptBtn}</div>
            </div>
            <hr/>

            `
        allAnswers.appendChild(answerBox)
    }
    if (question.answers.length<=0)
    {
        var answerBox = document.createElement("div")
        answerBox.innerHTML =
            `
            No answer yet.
            <hr/>
            `
        allAnswers.appendChild(answerBox)
    }
}
function AcceptAnswer(obj,answerId)
{
    var acceptance = "0"
    if (obj.textContent == "Accept") {
        obj.textContent = "Reject"
        obj.title="click to reject"
        acceptance = "1"
        document.getElementById(answerId + "-check").textContent ="✔️"
    }
    else
    {
        obj.title = "click to accept"
        obj.textContent = "Accept"
        document.getElementById(answerId + "-check").textContent = ""
    }
    $.ajax({
        type: "POST",
        url: "Answers.aspx/AcceptAnswer?paramater=parameter",


        contentType: "application/json; charset=utf-8",
        data: "{answerId:'" + (answerId).toString() + "',acceptance:'" + acceptance + "'}",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            var message = result.d
        },
        error: function (xhr, status, error) {
            alert("error in posting answer: " + xhr.responseText);
        }
    });
}
function Post() {
    var descriptionValue = document.getElementById('answerText').value
    if (descriptionValue.length < 25) {
        alert("Inappropriate length of answer, must be at least 25 characters.")
    }
    else {


        var description = descriptionValue;//.replace('\','\\')
        description=description.replace(/'/g, '\\\'')
        description = description.replace(/"/g, '\\\"')
        console.log(description, descriptionValue.length)
        $.ajax({
            type: "POST",
            url: "Answers.aspx/PostAnswer?paramater=parameter",


            contentType: "application/json; charset=utf-8",
            data: "{questionId:'" +(question.id).toString() + "',description:'" + description + "'}",

            dataType: "json",

            async: "false",

            cache: "false",

            success: function (result) {
                var message = result.d
                alert(message)
                if (message.includes("success")) { 
                
                    window.location.href = "Questions.aspx"
                }
            },
            error: function (xhr, status, error) {
                alert("error in posting answer: " + xhr.responseText);
            }
        });
    }
}
function CheckUserVoted(checkType,answerId)
{

    if (user!="none") { 
        $.ajax({
            type: "POST",
            url: "Answers.aspx/UserVote?paramater=parameter",


            contentType: "application/json; charset=utf-8",
            data: "{checkingType:'" + checkType + "',questionId:'" + (question.id).toString() + "', answerId:'" + answerId.toString() + "',userId:'" + (user[1]).toString() + "'}",

            dataType: "json",

            async: "false",

            cache: "false",

            success: function (result) {
                var message = result.d
                UpdateButtonStatus(parseInt(message), checkType, answerId.toString(), (question.id).toString())


            },
            error: function (xhr, status, error) {
                alert("error in posting answer: " + xhr.responseText);
            }
        });
    }

    

}
function UpdateVote(obj, opponentId)

{
    if (user != "none")
    { 
        var idParts = obj.id.split('-');
        var voteDisplay = document.getElementById(idParts[0] + "-" + idParts[1])
        var vote = parseInt(voteDisplay.textContent)
        var action = 0;
        var oppositeBtn = document.getElementById(opponentId)

        if (obj.style.backgroundColor == "blue") {
            obj.style.backgroundColor = "transparent"
        
            if (idParts[2] == "up") {
                vote -= 1
                voteDisplay.textContent = `${vote}`
            }
            else {
                vote += 1
                voteDisplay.textContent = `${vote}`
            }
  
        }
        else
        {
            obj.style.backgroundColor = "blue"
            if (oppositeBtn.style.backgroundColor == "blue") {
                oppositeBtn.style.backgroundColor = "transparent"
                if (idParts[2] == "up") {
                    action = 1
                    vote += 1
                    voteDisplay.textContent = `${vote}`
                }
                else {
                    action = -1
                    vote -= 1
                    voteDisplay.textContent = `${vote}`
                }
            }
            if (idParts[2] == "up") {
                action = 1
                vote += 1
                voteDisplay.textContent = `${vote}`
            }
            else {
                action = -1
                vote -= 1
                voteDisplay.textContent = `${vote}`
            }
        }

            UpdateAnswerVote(idParts[0], action)
    }
    else {
        alert("Please login to vote.")
    }

}
function UpdateAnswerVote(answerId, action)
{
    if (user != "none") {
        $.ajax({
            type: "POST",
            url: "Answers.aspx/UpdateVote?paramater=parameter",


            contentType: "application/json; charset=utf-8",
            data: "{answerId:'" + answerId + "',userId:'" + (user[1]).toString() +  "',action:'" + (action).toString() + "'}",

            dataType: "json",

            async: "false",

            cache: "false",

            success: function (result) {
                var message = result.d
                //UpdateButtonStatus(parseInt(message), checkType, answerId, (question.id).toString())


            },
            error: function (xhr, status, error) {
                alert("error in updating vote: " + xhr.responseText);
            }
        });
    }
    else
    {
        alert("Please login to vote.")
    }
}
function UpdateButtonStatus(status, checkType, answerId, questionId)
{
    var buttonType = "q"
    var id = questionId.toString()

    if (checkType == "answer")
    {
        buttonType = "a"
        id = answerId.toString()
    }


    if (status == 1) {
        document.getElementById(id + "-" + buttonType + "-up").style.backgroundColor = 'blue';
    }
    else if (status == -1) {
        document.getElementById(id + "-" + buttonType + "-down").style.backgroundColor = 'blue';
    }
    voteState = status;
    console.log(voteState)
}



//▲▼▲

//OnKeyDown = "if(event.keyCode===9){var v=this.value,s=this.selectionStart,e=this.selectionEnd;this.value=v.substring(0, s)+'\t'+v.substring(e);this.selectionStart=this.selectionEnd=s+1;return false;}"