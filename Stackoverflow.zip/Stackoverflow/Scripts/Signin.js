﻿function Login() {

    var emailBox = document.getElementById('email')
    var passwordBox = document.getElementById('password')

    var emailvalue, passwordvalue

    emailvalue = emailBox.value
    passwordvalue = passwordBox.value

    if (Validate(emailvalue, passwordvalue)) {
        ValidateOnServerSide(emailvalue, passwordvalue)
    }
}
function ValidateOnServerSide(emailvalue, passwordvalue) {
    $.ajax({
        type: "POST",
        url: "Signin.aspx/userSignin?paramater=parameter",
        data: "{ email: '" + emailvalue + "',password: '" + passwordvalue + "'}",

        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            var message
            var userdata = result.d.split(",")
            var returnedMsg = userdata[0]
            switch (returnedMsg) {
                case "Incorrect":
                    message = "Incorrect Email or Password"
                    break;
                case "success":
                    message = "Login successfully"
                    break;
            }
            alert(message);
            if (returnedMsg == "success") {
                //console.log("NO")
                sessionStorage.setItem("user", userdata)

                //setTimeout(window.location.href = sessionStorage["redirectSite"], 200)
                setTimeout(window.location.href = "Questions.aspx", 200)
            }
        }
    });
}
function Validate(emailvalue, passwordvalue) {

    if (emailvalue == "") {
        alert("Please enter an email")
        return false;
    }
    else if (passwordvalue == "") {
        alert("Please enter a password")
        return false;
    }

    return true;
}

function ShowPassword(id) {
    var pwdTag = document.getElementById(id)
    if (pwdTag.type == "password") {
        pwdTag.setAttribute('type', 'text');
    }
    else {
        pwdTag.setAttribute('type', 'password');
    }
}