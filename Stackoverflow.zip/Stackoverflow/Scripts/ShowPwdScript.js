﻿function ShowPassword(id) {
    var pwdTag = document.getElementById(id)
    if (pwdTag.type == "password") {
        pwdTag.setAttribute('type', 'text');
    }
    else {
        pwdTag.setAttribute('type', 'password');
    }
}