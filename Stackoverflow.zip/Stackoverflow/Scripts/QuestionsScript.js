﻿var questions = []
GetAllQuestions()
function GetAllQuestions()
{
    $.ajax({
        type: "POST",
        url: "Questions.aspx/GetAllQuestions?paramater=parameter",


        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            questions = result.d
            //console.log(questions)
            DisplayQuestions(questions)
        },
        error: function (error) {
            alert('error; ' + eval(error));
        }
    });
}


function DisplayQuestions(questionsList)
{
    //console.log("here", questionsList)
    for (var i = 0; i < questionsList.length; i++)
    {

        var tableRow = document.createElement("tr")
        var tagContainer = document.createElement("div")
        tagContainer.classList.add('bottomLeft')
        for (var j = 0; j < questionsList[i].tags.length; j++)
        {
            var tagbox = document.createElement("div")
            tagbox.classList.add("tagbody")
            //tagbox.id = `${i}-${j}-${questionsList[i].tags[j].id}`
            tagbox.innerHTML = `${questionsList[i].tags[j].name}`
           //tagbox.onclick = function () { SearchByTag(questionsList[i].tags[j].id); };
            tagContainer.appendChild(tagbox)

        }
        var displayedDescription = questionsList[i].description
        if (displayedDescription.length > 200)
        {
            displayedDescription=displayedDescription.substring(0,200)+"..."
        }
        tableRow.innerHTML = `<td>
            <div class="left">
                <p class="text-right"><span >${questionsList[i].vote}</span> vote</p>
                <p class="text-right"><span >${questionsList[i].answers.length}</span> Answer</p>
            </div>
            <div class="right">
                <h2  onclick="ShowAnswers(${i})" class="title text-primary">${questionsList[i].title}</h2>
                <p class="questionContent">
                     ${displayedDescription}
                 </p>
                <div class="questionBottom">
                    <div class="bottomLeft">
                    ${tagContainer.innerHTML}
                       </div>
                    <div class=" bottomRight">By <span class="text-primary">${questionsList[i].username}</span> on ${questionsList[i].uploadDatetime}</div>

                </div>
            </div>
        </td>`
        $('#questionsTable').find('tbody').append(tableRow)

    }
}



$(document).ready(function () {

    $(".dataTables_empty").empty();
});




function ShowAnswers(questionIndex) {
    //console.log("here it is", questions[parseInt(questionIndex)])
    sessionStorage.setItem('Question', JSON.stringify(questions[parseInt(questionIndex)]));
    window.location.href = "Answers.aspx";
}
