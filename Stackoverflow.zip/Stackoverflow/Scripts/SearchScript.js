﻿
if (sessionStorage.getItem("searchItem") != "" && sessionStorage.getItem("searchItem") != null)
{
    var searchBar = document.getElementById('navbarSearch')
    searchBar.value = sessionStorage.getItem("searchItem")
}
if (sessionStorage.getItem("user") == "" || sessionStorage.getItem("user") == null) {
    document.getElementById("userStatus").style.display = "none"
}
else
{
    document.getElementById("userStatus").style.display="flex"
}
function Search(IsClicked)
{
    var searchBar = document.getElementById('navbarSearch')
    var searchItem = searchBar.value

    if ((searchItem != "" && searchItem != null) && IsClicked=='yes') {
        sessionStorage.setItem("searchItem", searchItem)
        window.location.href = "SearchedQuestions.aspx"
    }
    else if ((searchItem == "" || searchItem == null) && IsClicked == 'no')
    {
        sessionStorage.setItem("searchItem", searchItem)
        window.location.href="Questions.aspx"
    }

}
function Logout()
{
    sessionStorage.clear();
    $.ajax({
        type: "POST",
        url: "Questions.aspx/Logout",


        contentType: "application/json; charset=utf-8",

        dataType: "json",
        async: "false",

        cache: "false",

        success: function (result) {
            alert("You are logged out.");
            setTimeout(window.location.href = "Questions.aspx", 200)
        },
        error: function (error) {
            alert('error; ' + eval(error));
        }
    });
}

