﻿var selectedTags = []
var tagData=[]
function Post()
{
    var titleValue = document.getElementById('title').value
    var descriptionValue = document.getElementById('description').value
    if (titleValue.length < 15) {
        alert("Inappropriate length of title")
    }
    else if (descriptionValue.length < 25) {
        alert("Inappropriate length of description")
    }
    else if (selectedTags.length < 1) {
        alert("Inappropriate number of selected tags. Select 1 to 5 tags")
    }
    else
    {
        if (titleValue.length > 400) { 
            //descriptionValue = descriptionValue.substring(0, 26);
            alert("Title length exceeds the limit of 400 characters.")
            return
        }
        const selectedTag = selectedTags.join();
        
        var description = descriptionValue.replace(/'/g, '\\\'')
        description = description.replace(/"/g, '\\\"')
        var title = titleValue.replace(/'/g, '\\\"')
        title = title.replace(/'/g, '\\\'')
        console.log(selectedTag, selectedTags, title, description, descriptionValue.length)
        $.ajax({
            type: "POST",
            url: "PostQuestion.aspx/AskQuestion?paramater=parameter",


            contentType: "application/json; charset=utf-8",
            data: "{title:'" + title+ "',description:'" + description + "',tagsId:'" + selectedTag + "'}",

            dataType: "json",

            async: "false",

            cache: "false",

            success: function (result) {
                var userdata = result.d
                alert("Question successfully posted")

                ClearData()
            },
            error: function (xhr, status, error) {
                alert("error in posting question: "+xhr.responseText);
            }
        });
    }
}
function ClearData()
{
    document.getElementById('title').value = ""
    document.getElementById('description').value = ""
    selectedTags = []
}
function GetSearchedTags(id)
{
    RemoveChilds("suggestedTags")
    var element = document.getElementById(id);
    var searchItem = element.value
    if (searchItem != "" && searchItem != null) {
        $.ajax({
            type: "POST",
            url: "PostQuestion.aspx/GetAllSearchedTags?paramater=parameter",


            contentType: "application/json; charset=utf-8",
            data: "{searchText:'" + searchItem + "'}",

            dataType: "json",

            async: "false",

            cache: "false",

            success: function (result) {
                var tagsdata = result.d
                //console.log(userdata)
                DisplayTags(tagsdata)
            },
            error: function (error) {
                alert('error in tag search; ' + eval(error));
            }
        });
    }
    else
    {
        RemoveChilds("suggestedTags")
    }
}
function RemoveChilds(id)
{
    const parent = document.getElementById(id)
    while (parent.firstChild) {
        parent.firstChild.remove()
    }
}



function DisplayTags(data) {
    tagData = data
    var suggestedTagsElement = document.getElementById("suggestedTags")
    console.log(tagData.length)
    for (var i=0; i < tagData.length; i++) {
        var child = document.createElement("span")
        child.classList.add('tagbody')
        child.id = i
        child.onclick = function (event) {
            AddTag(event.target);
        }
        child.innerHTML =  `${tagData[i].name}`
        suggestedTagsElement.appendChild(child)
    }
}
function AddTag(obj)
{
    if (!selectedTags.includes(tagData[obj.id].id))
    { 
        selectedTags.push(tagData[obj.id].id)
        var selectedTagsElement = document.getElementById("selectedTags")
        var child = document.createElement("span")
        child.classList.add('selectedTagbody')
        child.innerHTML = `${obj.innerHTML} <button type="button" class="cancelTag" onclick="RemoveTag(${obj.id},this)">X</button>`
        selectedTagsElement.appendChild(child)
    }
}

function RemoveTag(id,obj)
{
    //console.log(selectedTags)
    var cancelbtnParent = obj.parentNode
    cancelbtnParent.remove()
    if (id > -1) { // only splice array when item is found
        selectedTags.splice(id, 1); // 2nd parameter means remove one item only
    }

}