﻿function Register() {
    var nameBox = document.getElementById('username')
    var emailBox = document.getElementById('email')
    var passwordBox = document.getElementById('password')
    var repasswordBox = document.getElementById('password2')
    var countryBox = document.getElementById('country')


    var namevalue, emailvalue, passwordvalue, repasswordvalue, countryvalue
    namevalue = nameBox.value
    emailvalue = emailBox.value

    passwordvalue = passwordBox.value
    repasswordvalue = repasswordBox.value

    countryvalue = countryBox.value

    if (Validate(namevalue, emailvalue, passwordvalue, repasswordvalue, countryvalue)) {
        RegisterOnServerSide(namevalue, emailvalue, passwordvalue, repasswordvalue, countryvalue)
    }
}

function Validate(namevalue, emailvalue, passwordvalue, repasswordvalue, countryvalue) {

    if (namevalue == "") {
        alert("Please enter a user name")
        return false;
    }
    else if (emailvalue == "") {
        alert("Please enter an email")
        return false;
    }
    else if (!emailvalue.includes("@") || !emailvalue.endsWith(".com")) {
        alert("Email format is invalid")
        return false;
    }
    else if (passwordvalue == "") {
        alert("Please enter a password")
        return false;
    }
    else if (repasswordvalue == "") {
        alert("Please confirm password")
        return false;

    }
    else if (countryvalue == "") {
        alert("Please provide an country")
        return false;
    }
    else if (passwordvalue != repasswordvalue) {
        alert("Passwords do not match")
        return false;
    }
    else if (!PasswordValidation(passwordvalue)) {
        alert("Password must contain a symbol, a lower and an upper case letter, a numeric and must be 8 to 15 characters long")
        return false;
    }
    return true;
}

function PasswordValidation(password) {
    // Validate lowercase letters
    var lowerCaseLetters = /[a-z]/g;
    if (!password.match(lowerCaseLetters)) {
        return false;

    }
    // Validate capital letters
    var upperCaseLetters = /[A-Z]/g;
    if (!password.match(upperCaseLetters)) {
        return false;
    }
    // Validate numbers
    var numbers = /[0-9]/g;
    if (!password.match(numbers)) {
        return false;
    }


    // Validate length

    if (password.length < 8 || password.length > 15) {
        return false;
    }
    return true;
}



function RegisterOnServerSide(namevalue, emailvalue, passwordvalue, repasswordvalue, countryvalue) {
    $.ajax({
        type: "POST",
        url: "Signup.aspx/UserSignup?paramater=parameter",
        data: "{ name: '" + namevalue + "',email: '" + emailvalue + "',password: '" + passwordvalue + "',password2: '" + repasswordvalue + "',country: '" + countryvalue + "'}",

        contentType: "application/json; charset=utf-8",

        dataType: "json",

        async: "false",

        cache: "false",

        success: function (result) {
            var userdata = result.d.split(",")
            var message = userdata[0]
            if (result.d.includes("success")) {
                sessionStorage.setItem("user", userdata)
                setTimeout(window.location.href = "Questions.aspx", 200)
            }

            alert(message);
        }
    });
}
function ShowPassword(id) {
    var pwdTag = document.getElementById(id)
    if (pwdTag.type == "password") {
        pwdTag.setAttribute('type', 'text');
    }
    else {
        pwdTag.setAttribute('type', 'password');
    }
}