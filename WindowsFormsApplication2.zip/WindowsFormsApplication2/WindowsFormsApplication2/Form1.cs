﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class Form1 : Form
    {
      public static int month, year;
      
        public Form1()
        {
            InitializeComponent();
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DisplayDays();
        }



        private void DisplayDays()
        {
           
              

            DateTime now = DateTime.Now;
            month = now.Month;
            year = now.Year;
            

            
           
            string month_name = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);
         
            lbl_current_date_year.Text = month_name + " " + year;

            DateTime startofmonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int dayoftheweek = Convert.ToInt32(startofmonth.DayOfWeek.ToString("d"))+1;

            //blaank sapce
            for (int i = 1; i < dayoftheweek; i++)
            {
                UserControl1 ucblank = new UserControl1();
                //ucblank.Location = new Point(i*20);
                flowLayoutPanel1.Controls.Add(ucblank);
                //flowLayoutPanel1.Controls.Add(ucblank);

            }
            //adddays
            for (int i = 1; i < days; i++)
            {
                UserControlday ucdays = new UserControlday();
                ucdays.days(i);
               
                

                 flowLayoutPanel1.Controls.Add(ucdays);

            }

        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        

        private void flowLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void next_Click(object sender, EventArgs e)
        {
            flowLayoutPanel1.Controls.Clear();
            month++;

            if (month == 12)
            {
                year++;
                month = 1;

            }
            else  
            {
                

            }

         

            string month_name = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);

            lbl_current_date_year.Text = month_name + " " + year;



            DateTime startofmonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int dayoftheweek = Convert.ToInt32(startofmonth.DayOfWeek.ToString("d")) + 1;

            //blaank sapce
            for (int i = 1; i < dayoftheweek; i++)
            {
                UserControl1 ucblank = new UserControl1();
                //ucblank.Location = new Point(i*20);
                flowLayoutPanel1.Controls.Add(ucblank);
                //flowLayoutPanel1.Controls.Add(ucblank);

            }
            //adddays
            for (int i = 1; i < days; i++)
            {
                UserControlday ucdays = new UserControlday();
                ucdays.days(i);
                flowLayoutPanel1.Controls.Add(ucdays);


            }
        }

        private void previous_Click(object sender, EventArgs e)
        {

            flowLayoutPanel1.Controls.Clear();
            month--;

            if (month == 1)
            {
                year--;
                month = 11;

            }
            else
            {


            }


            string month_name = DateTimeFormatInfo.CurrentInfo.GetMonthName(month);

            lbl_current_date_year.Text = month_name + " " + year;


            DateTime startofmonth = new DateTime(year, month, 1);
            int days = DateTime.DaysInMonth(year, month);
            int dayoftheweek = Convert.ToInt32(startofmonth.DayOfWeek.ToString("d")) + 1;

            //blaank sapce
            for (int i = 1; i < dayoftheweek; i++)
            {
                UserControl1 ucblank = new UserControl1();
                //ucblank.Location = new Point(i*20);
                flowLayoutPanel1.Controls.Add(ucblank);
                //flowLayoutPanel1.Controls.Add(ucblank);

            }
            //adddays
            for (int i = 1; i < days; i++)
            {
                UserControlday ucdays = new UserControlday();
                ucdays.days(i);
                flowLayoutPanel1.Controls.Add(ucdays);


            }

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void label_real_time_Click(object sender, EventArgs e)
        {

        }


        private void timer1_Tick(object sender, EventArgs e)
        {

            DateTime datetime = DateTime.Now;


            this.lbl_real_time.Text = datetime.ToString("HH:mm:ss");
            this.lbl_am.Text = datetime.ToString("tt");
            this.lbl_full_date.Text = datetime.ToString("ddd,MMMMM dd, yyyy");

        }
       
        private void am_Click(object sender, EventArgs e)
        {

           // DateTime datetime = DateTime.Now;


            //this.label_real_time.Text = datetime.ToString("HH:mm:ss");
           //this.lb_am.Text = datetime.ToString("d");
           // this.label_real_time.Text = datetime.ToString("tt");

        }

        private void full_date_Click(object sender, EventArgs e)
        {

        }
        
            
        


    
      }
}
