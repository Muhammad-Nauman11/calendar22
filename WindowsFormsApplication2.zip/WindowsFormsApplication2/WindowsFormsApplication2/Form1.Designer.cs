﻿namespace WindowsFormsApplication2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.btn_next = new System.Windows.Forms.Button();
            this.btn_previous = new System.Windows.Forms.Button();
            this.lbl_current_date_year = new System.Windows.Forms.Label();
            this.lbl_real_time = new System.Windows.Forms.Label();
            this.lbl_am = new System.Windows.Forms.Label();
            this.lbl_full_date = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl1.Location = new System.Drawing.Point(66, 157);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(25, 17);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Su";
            this.lbl1.Click += new System.EventHandler(this.label1_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.flowLayoutPanel1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(45, 187);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(565, 469);
            this.flowLayoutPanel1.TabIndex = 1;
            this.flowLayoutPanel1.Paint += new System.Windows.Forms.PaintEventHandler(this.flowLayoutPanel1_Paint);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl2.Location = new System.Drawing.Point(150, 157);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(27, 17);
            this.lbl2.TabIndex = 2;
            this.lbl2.Text = "Mo";
            this.lbl2.Click += new System.EventHandler(this.label2_Click);
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbl3.Location = new System.Drawing.Point(232, 157);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(25, 17);
            this.lbl3.TabIndex = 3;
            this.lbl3.Text = "Tu";
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Location = new System.Drawing.Point(153, 0);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(8, 8);
            this.flowLayoutPanel2.TabIndex = 4;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Location = new System.Drawing.Point(307, 157);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(29, 17);
            this.lbl4.TabIndex = 0;
            this.lbl4.Text = "We";
            this.lbl4.Click += new System.EventHandler(this.label4_Click);
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Location = new System.Drawing.Point(385, 157);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(25, 17);
            this.lbl5.TabIndex = 5;
            this.lbl5.Text = "Th";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Location = new System.Drawing.Point(470, 157);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(21, 17);
            this.lbl6.TabIndex = 6;
            this.lbl6.Text = "Fr";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Location = new System.Drawing.Point(554, 157);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(25, 17);
            this.lbl7.TabIndex = 7;
            this.lbl7.Text = "Sa";
            // 
            // btn_next
            // 
            this.btn_next.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_next.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_next.Location = new System.Drawing.Point(535, 110);
            this.btn_next.Name = "btn_next";
            this.btn_next.Size = new System.Drawing.Size(44, 23);
            this.btn_next.TabIndex = 0;
            this.btn_next.Text = "NEXT";
            this.btn_next.UseVisualStyleBackColor = false;
            this.btn_next.Click += new System.EventHandler(this.next_Click);
            // 
            // btn_previous
            // 
            this.btn_previous.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btn_previous.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btn_previous.Location = new System.Drawing.Point(482, 110);
            this.btn_previous.Name = "btn_previous";
            this.btn_previous.Size = new System.Drawing.Size(41, 23);
            this.btn_previous.TabIndex = 8;
            this.btn_previous.Text = "PREVIOUS";
            this.btn_previous.UseVisualStyleBackColor = false;
            this.btn_previous.Click += new System.EventHandler(this.previous_Click);
            // 
            // lbl_current_date_year
            // 
            this.lbl_current_date_year.AutoSize = true;
            this.lbl_current_date_year.Location = new System.Drawing.Point(84, 116);
            this.lbl_current_date_year.Name = "lbl_current_date_year";
            this.lbl_current_date_year.Size = new System.Drawing.Size(77, 17);
            this.lbl_current_date_year.TabIndex = 9;
            this.lbl_current_date_year.Text = "Wegggggg";
            this.lbl_current_date_year.Click += new System.EventHandler(this.label8_Click);
            // 
            // lbl_real_time
            // 
            this.lbl_real_time.AllowDrop = true;
            this.lbl_real_time.AutoEllipsis = true;
            this.lbl_real_time.Font = new System.Drawing.Font("Microsoft Sans Serif", 28.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_real_time.Location = new System.Drawing.Point(45, 11);
            this.lbl_real_time.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbl_real_time.Name = "lbl_real_time";
            this.lbl_real_time.Size = new System.Drawing.Size(260, 73);
            this.lbl_real_time.TabIndex = 20;
            this.lbl_real_time.Text = "Wegggggg";
            this.lbl_real_time.Click += new System.EventHandler(this.label_real_time_Click);
            // 
            // lbl_am
            // 
            this.lbl_am.AllowDrop = true;
            this.lbl_am.AutoEllipsis = true;
            this.lbl_am.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_am.Location = new System.Drawing.Point(258, 22);
            this.lbl_am.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbl_am.Name = "lbl_am";
            this.lbl_am.Size = new System.Drawing.Size(67, 50);
            this.lbl_am.TabIndex = 21;
            this.lbl_am.Text = "ii";
            this.lbl_am.Click += new System.EventHandler(this.am_Click);
            // 
            // lbl_full_date
            // 
            this.lbl_full_date.AllowDrop = true;
            this.lbl_full_date.AutoEllipsis = true;
            this.lbl_full_date.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_full_date.Location = new System.Drawing.Point(59, 72);
            this.lbl_full_date.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.lbl_full_date.Name = "lbl_full_date";
            this.lbl_full_date.Size = new System.Drawing.Size(551, 44);
            this.lbl_full_date.TabIndex = 22;
            this.lbl_full_date.Text = "Wegggggg";
            this.lbl_full_date.Click += new System.EventHandler(this.full_date_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(733, 782);
            this.Controls.Add(this.lbl_full_date);
            this.Controls.Add(this.lbl_am);
            this.Controls.Add(this.lbl_real_time);
            this.Controls.Add(this.lbl_current_date_year);
            this.Controls.Add(this.btn_previous);
            this.Controls.Add(this.btn_next);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.flowLayoutPanel2);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.lbl1);
            this.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Button btn_next;
        private System.Windows.Forms.Button btn_previous;
        private System.Windows.Forms.Label lbl_current_date_year;
        private System.Windows.Forms.Label lbl_real_time;
        private System.Windows.Forms.Label lbl_am;
        private System.Windows.Forms.Label lbl_full_date;
    }
}

