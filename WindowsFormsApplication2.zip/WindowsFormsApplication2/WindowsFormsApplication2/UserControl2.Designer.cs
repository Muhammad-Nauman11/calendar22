﻿namespace WindowsFormsApplication2
{
    partial class UserControlday
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbday = new System.Windows.Forms.Label();
            this.btndate = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lbday
            // 
            this.lbday.AutoSize = true;
            this.lbday.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lbday.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbday.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lbday.Location = new System.Drawing.Point(17, 17);
            this.lbday.Name = "lbday";
            this.lbday.Size = new System.Drawing.Size(0, 20);
            this.lbday.TabIndex = 0;
            // 
            // btndate
            // 
            this.btndate.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btndate.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btndate.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btndate.Location = new System.Drawing.Point(0, 17);
            this.btndate.Name = "btndate";
            this.btndate.Size = new System.Drawing.Size(73, 47);
            this.btndate.TabIndex = 1;
            this.btndate.Text = "button1";
            this.btndate.UseVisualStyleBackColor = false;
            this.btndate.Click += new System.EventHandler(this.btndate_Click);
            // 
            // UserControlday
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Controls.Add(this.btndate);
            this.Controls.Add(this.lbday);
            this.Name = "UserControlday";
            this.Size = new System.Drawing.Size(73, 64);
            this.Load += new System.EventHandler(this.UserControlday_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbday;
        private System.Windows.Forms.Button btndate;
    }
}
