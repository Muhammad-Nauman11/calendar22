﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication2
{
    public partial class UserControlday : UserControl
    {
        public UserControlday()
        {
            InitializeComponent();
        }

        private void UserControlday_Load(object sender, EventArgs e)
        {

        }
        public void days(int numday)
        {
            btndate.Text = numday+"";
        }

        private void btndate_Click(object sender, EventArgs e)
        {
            Event popup = new Event();
            popup.Show();
        }
    }
}
