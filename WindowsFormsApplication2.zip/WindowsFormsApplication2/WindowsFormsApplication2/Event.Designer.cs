﻿namespace WindowsFormsApplication2
{
    partial class Event
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_Box1 = new System.Windows.Forms.TextBox();
            this.txt_descrip = new System.Windows.Forms.TextBox();
            this.lbl_event_date = new System.Windows.Forms.Label();
            this.lbl_event_description = new System.Windows.Forms.Label();
            this.btn_create = new System.Windows.Forms.Button();
            this.btn_write = new System.Windows.Forms.Button();
            this.btn_del = new System.Windows.Forms.Button();
            this.btn_read = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txt_Box1
            // 
            this.txt_Box1.Location = new System.Drawing.Point(54, 73);
            this.txt_Box1.Name = "txt_Box1";
            this.txt_Box1.Size = new System.Drawing.Size(335, 22);
            this.txt_Box1.TabIndex = 0;
            this.txt_Box1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txt_descrip
            // 
            this.txt_descrip.Location = new System.Drawing.Point(54, 152);
            this.txt_descrip.Multiline = true;
            this.txt_descrip.Name = "txt_descrip";
            this.txt_descrip.Size = new System.Drawing.Size(335, 22);
            this.txt_descrip.TabIndex = 1;
            this.txt_descrip.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // lbl_event_date
            // 
            this.lbl_event_date.AutoSize = true;
            this.lbl_event_date.Location = new System.Drawing.Point(51, 53);
            this.lbl_event_date.Name = "lbl_event_date";
            this.lbl_event_date.Size = new System.Drawing.Size(45, 17);
            this.lbl_event_date.TabIndex = 2;
            this.lbl_event_date.Text = "DATE";
            this.lbl_event_date.Click += new System.EventHandler(this.label1_Click);
            // 
            // lbl_event_description
            // 
            this.lbl_event_description.AutoSize = true;
            this.lbl_event_description.Location = new System.Drawing.Point(51, 117);
            this.lbl_event_description.Name = "lbl_event_description";
            this.lbl_event_description.Size = new System.Drawing.Size(54, 17);
            this.lbl_event_description.TabIndex = 3;
            this.lbl_event_description.Text = "EVENT";
            // 
            // btn_create
            // 
            this.btn_create.Location = new System.Drawing.Point(45, 209);
            this.btn_create.Name = "btn_create";
            this.btn_create.Size = new System.Drawing.Size(75, 23);
            this.btn_create.TabIndex = 4;
            this.btn_create.Text = "SAVE";
            this.btn_create.UseVisualStyleBackColor = true;
            this.btn_create.Click += new System.EventHandler(this.event_button1_Click);
            // 
            // btn_write
            // 
            this.btn_write.Location = new System.Drawing.Point(139, 209);
            this.btn_write.Name = "btn_write";
            this.btn_write.Size = new System.Drawing.Size(75, 23);
            this.btn_write.TabIndex = 5;
            this.btn_write.Text = "write";
            this.btn_write.UseVisualStyleBackColor = true;
            this.btn_write.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_del
            // 
            this.btn_del.Location = new System.Drawing.Point(349, 209);
            this.btn_del.Name = "btn_del";
            this.btn_del.Size = new System.Drawing.Size(73, 23);
            this.btn_del.TabIndex = 6;
            this.btn_del.Text = "del";
            this.btn_del.UseVisualStyleBackColor = true;
            this.btn_del.Click += new System.EventHandler(this.del_Click);
            // 
            // btn_read
            // 
            this.btn_read.Location = new System.Drawing.Point(258, 209);
            this.btn_read.Name = "btn_read";
            this.btn_read.Size = new System.Drawing.Size(75, 23);
            this.btn_read.TabIndex = 7;
            this.btn_read.Text = "read";
            this.btn_read.UseVisualStyleBackColor = true;
            this.btn_read.Click += new System.EventHandler(this.read_Click);
            // 
            // Event
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(434, 325);
            this.Controls.Add(this.btn_read);
            this.Controls.Add(this.btn_del);
            this.Controls.Add(this.btn_write);
            this.Controls.Add(this.btn_create);
            this.Controls.Add(this.lbl_event_description);
            this.Controls.Add(this.lbl_event_date);
            this.Controls.Add(this.txt_descrip);
            this.Controls.Add(this.txt_Box1);
            this.Name = "Event";
            this.Text = "Event";
            this.Load += new System.EventHandler(this.Event_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_Box1;
        private System.Windows.Forms.TextBox txt_descrip;
        private System.Windows.Forms.Label lbl_event_date;
        private System.Windows.Forms.Label lbl_event_description;
        private System.Windows.Forms.Button btn_create;
        private System.Windows.Forms.Button btn_write;
        private System.Windows.Forms.Button btn_del;
        private System.Windows.Forms.Button btn_read;
    }
}