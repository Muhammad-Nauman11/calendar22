﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace WindowsFormsApplication2
{
    public partial class Event : Form
    {
        string path = Environment.CurrentDirectory + "/" + "event.txt";
        public Event()
        {

            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Event_Load(object sender, EventArgs e)
        {

        }

        private void event_button1_Click(object sender, EventArgs e)
        {
            //string path = Environment.CurrentDirectory +"/"+"event.txt";
            if (!File.Exists(path))
            {
                File.CreateText(path);
                MessageBox.Show("event set");




            }

            // TextWriter txt = new StreamWriter("C:\\calender\\demo.txt");
            //  txt.Write(textBox1.Text);
            //   txt.Close();  

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (StreamWriter sw = new StreamWriter(path))
            {
                sw.WriteLine("enter date");
            }

        }

        private void read_Click(object sender, EventArgs e)
        {
            using (StreamReader sr = new StreamReader(path))
            {
                string txt = sr.ReadLine();
                txt_descrip.Text = txt;
                
               // DateTime now = new.now;
                



            }


        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void del_Click(object sender, EventArgs e)
        {
            if (!File.Exists(path))
            {
                File.Delete(path);
                MessageBox.Show("event DELETED");

            }


            // TextWriter txt = new StreamWriter("C:\\Users\\hiba.rashid\\Documents\\Visual Studio 2013\\Projects\\WindowsFormsApplication2\\WindowsFormsApplication2\\bin\\Debug\\event.txt");
            //  txt.Write(textBox1.Text);
            //   txt.Close();  

        }
    }
}
